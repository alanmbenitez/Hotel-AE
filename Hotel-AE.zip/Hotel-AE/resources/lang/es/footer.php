<?php
/**
 * 
 */
return [
    /*
    |--------------------------------------------------------------------------
    | {Idioma} - {Pais} - Base
    |--------------------------------------------------------------------------
    | Descripccion
    */
    // EJ
    'text' => 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet.',
    'contact' => 'Contáctenos',
    'data' => [
        'address' => 'Bartolomé Mitre 3410, C1201 AAN, Buenos Aires',
        'phone' => '+54 011 4867-1265',
        'wpp' => '+54 9 11 4048 0054',
        'email' => 'hotelairesexpress@hotmail.com'
    ]
    
];