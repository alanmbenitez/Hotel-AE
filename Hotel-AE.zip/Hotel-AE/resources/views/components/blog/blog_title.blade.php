<div class="page_title gradient_overlay hero_blog_img" >
    <div class="container">
        <div class="inner">
        <h1>{{__('blog.title_hero')}}</h1>
            
        </div>
    </div>
</div>