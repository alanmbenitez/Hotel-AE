<section id="testimonials" class="lightgrey_bg">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="main_title mt_wave a_left">
                    <h2>OUR HAPPY CLIENTS</h2>
                </div>
                <p class="main_description">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit.
                <br><br>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit.Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit.</p>
            </div>

            <div class="col-md-6">
                <div id="testimonials_slider" class="owl-carousel">
                    <!-- ITEM -->
                    <div class="item">
                        <img src="images/users/user1.jpg" alt="Image">
                        <div class="review_content">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore consequuntur, consequatur ad nesciunt nulla voluptate voluptates.</p>
                            <div class="review_rating">
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                            </div>
                            <div class="review_author">John Doe, Greece</div>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="item">
                        <img src="images/users/user2.jpg" alt="Image">
                        <div class="review_content">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore consequuntur, consequatur ad nesciunt nulla voluptate voluptates.</p>
                            <div class="review_rating">
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                            </div>
                            <div class="review_author">Ina Aldrich, Greece</div>
                        </div>
                    </div>
                    <!-- ITEM -->
                    <div class="item">
                        <img src="images/users/user3.jpg" alt="Image">
                        <div class="review_content">
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Labore consequuntur, consequatur ad nesciunt nulla voluptate voluptates.</p>
                            <div class="review_rating">
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star" aria-hidden="true"></i>
                                <i class="fa fa-star-o" aria-hidden="true"></i>
                            </div>
                            <div class="review_author">William Whiten, Greece</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>