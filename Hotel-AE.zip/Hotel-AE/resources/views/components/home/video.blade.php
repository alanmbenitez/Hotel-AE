<section id="video">
    <div class="inner gradient_overlay">
        <div class="container">
            <div class="video_popup">
                <a class="popup-vimeo" href="videos/hero_video.mp4"><i class="fa fa-play"></i></a>
            </div>
        </div>
    </div>
</section>