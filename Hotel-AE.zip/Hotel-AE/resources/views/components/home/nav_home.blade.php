<header class="fixed transparent">
    @component('components.general.menu_general')
           
       @endcomponent
     
</header>
