<div id="smoothpage" class="wrapper">

    <header class="fixed">
       @component('components.general.menu_general')
           
       @endcomponent
     
    </header>