<div class="main_title t_style a_left s_title mt50">
    <div class="c_inner">
        <h2 class="c_title"><?php echo e($rooms['title_service']); ?></h2>
    </div>
</div>
<div class="room_facilitys_list">
    <div class="all_facility_list">
       <?php $__currentLoopData = $rooms['informacion']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $columna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            
       <div class="col-sm-4 nopadding">
            <ul class="list-unstyled">
                <li><i class="fa fa-check"></i><?php echo e($columna['servicio1']); ?></li>
                <li><i class="fa fa-check"></i><?php echo e($columna['servicio2']); ?></li>
                <li><i class="fa fa-check"></i><?php echo e($columna['servicio3']); ?></li>
            </ul>
        </div>
       
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    
    </div>
</div><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/rooms/services_room.blade.php ENDPATH**/ ?>