<div class="page_title gradient_overlay hero_blog_img" >
    <div class="container">
        <div class="inner">
            <div class="row">
                <div class="col-md-6 col-sm-6">
                <h1><?php echo e($rooms['title']); ?></h1>
                    
                </div>
                <?php if($rooms['precio_num'] !== ''): ?>
                    
                <div class="col-md-6 col-sm-6">
                    <div class="price">
                        <div class="inner">
                        <?php echo e($rooms['precio_num']); ?><span><?php echo e($rooms['Precio_per_night']); ?></span>
                        </div>
                    </div>
                </div>  
                
                <?php endif; ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/rooms/hero_rooms.blade.php ENDPATH**/ ?>