<div class="similar_rooms">
    <div class="main_title t_style5 l_blue s_title a_left">
        <div class="c_inner">
        <h2 class="c_title"><?php echo e($rooms['title_rooms']); ?></h2>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $rooms['other_rooms']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="col-md-4">
            <article>
                <figure>
                <a href="<?php echo e($room['href']); ?>" 
                class="hover_effect h_blue h_link"><img 
                src="<?php echo e($room['src']); ?>" 
                alt="Image" 
                class="img-responsive"></a>
                <?php if($room['price']!==''): ?>
                <div class="price"><?php echo e($room['price']); ?>

                    <span><?php echo e($room['per_night']); ?></span>
                </div>
                <?php endif; ?>
                    <figcaption>
                        <h4><a href="room.html"><?php echo e($room['name']); ?></a></h4>
                    </figcaption>
                </figure>
            </article>
        </div>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
       
    </div>
</div><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/rooms/other_rooms.blade.php ENDPATH**/ ?>