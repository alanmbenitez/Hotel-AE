<div class="container">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle mobile_menu_btn" data-toggle="collapse" data-target=".mobile_menu" aria-expanded="false">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand light" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo $__env->yieldContent('logo_menu'); ?>" height="60" alt="Logo">
        </a>
        <a class="navbar-brand dark nodisplay" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('images\logo2.png')); ?>" height="60" alt="Logo">
        </a>
    </div>
    <nav id="main_menu" class="mobile_menu navbar-collapse">
        <ul class="nav navbar-nav">
            <li class="mobile_menu_title" style="display:none;">MENU</li>
            <li class="dropdown simple_menu nav_li_menu">
                <a href="<?php echo e(route('home')); ?>" data-toggle="dropdown" class="nav_a_menu" >HOME </a>
            </li>
            <li class="dropdown simple_menu nav_li_menu"><a href="#" data-toggle="dropdown" class="dropdown-toggle nav_a_menu" aria-expanded="true">ROOMS <b class="caret"></b></a>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo e(url('/rooms/individual')); ?>">Habitacion Simple</a></li>
                    <li><a href="buttons.html">Habitacion doble</a></li>
                    <li><a href="icons.html">Habitacion triple</a></li>
                </ul>
            </li>
          
            <li class="nav_li_menu ">
                <a href="<?php echo e(route('guia')); ?>" class="nav_a_menu"  >GUIA</a></li>
            <li class="nav_li_menu">
                <a class="nav_a_menu" href="blog.html" >CONTACTO</a></li>
                <?php if(false): ?>
                    
               
            <li class="dropdown simple_menu nav_li_menu">
                <?php if(App::getLocale() === 'en'): ?>
                <a href="#" data-toggle="dropdown" class="nav_a_menu  dropdown-toggle" aria-expanded="true"><i class="fa fa-globe"></i> | EN <b class="caret"></b></a>
                <?php else: ?>
                <a href="#" data-toggle="dropdown" class="nav_a_menu  dropdown-toggle" aria-expanded="true"><i class="fa fa-globe"></i> | ES <b class="caret"></b></a>
                <?php endif; ?>
                <?php if(config('locale.status') && count(config('locale.languages')) > 1): ?>
                <ul class=" lang_menu dropdown-menu">
                    <li><a id="lang_en" href="<?php echo route('lang.swap', 'en'); ?>">EN</a></li>
                    <li><a id="lang_es" href="<?php echo route('lang.swap', 'es'); ?>">ES</a></li>
                    
                </ul>
                <?php endif; ?>
            </li>
            <?php endif; ?>
        



            
        </ul>
    </nav>
</div><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/general/menu_general.blade.php ENDPATH**/ ?>