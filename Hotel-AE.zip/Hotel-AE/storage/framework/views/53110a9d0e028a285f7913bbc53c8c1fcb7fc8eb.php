<div id="smoothpage" class="wrapper">

    <header class="fixed">
       <?php $__env->startComponent('components.general.menu_general'); ?>
           
       <?php if (isset($__componentOriginald2912efef6a7334beefd759986d8ca3c0724aeb1)): ?>
<?php $component = $__componentOriginald2912efef6a7334beefd759986d8ca3c0724aeb1; ?>
<?php unset($__componentOriginald2912efef6a7334beefd759986d8ca3c0724aeb1); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
     
    </header><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/general/nav_general.blade.php ENDPATH**/ ?>