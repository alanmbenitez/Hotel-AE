<main class="blog">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <!-- ITEM -->
                <?php $__currentLoopData = $data['places']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="blog_list">
                    <figure>
                    <a href="<?php echo e($item['href']); ?>" class="hover_effect h_link h_blue">
                            <img src="<?php echo e($item['img']); ?>" class="img-responsive" alt="Image">
                        </a>
                    </figure>
                    <div class="details">
                        <h2><a href=<?php echo e($item['href']); ?>><?php echo e($item['title']); ?></a></h2>
                       
                        <p><?php echo e($item['parrafo']); ?></p>
                        <a class="button btn_blue " target="_blank" href=<?php echo e($item['href']); ?>><i class="fa fa-angle-double-right"></i> Leer más </a>
                    </div>
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-4">
                <?php $__env->startComponent('components.general.Form_reserva'); ?>
                <?php if (isset($__componentOriginald9c27f375020190b8bd5547f1ae37235430ab112)): ?>
<?php $component = $__componentOriginald9c27f375020190b8bd5547f1ae37235430ab112; ?>
<?php unset($__componentOriginald9c27f375020190b8bd5547f1ae37235430ab112); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
        </div><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/blog/blog_main.blade.php ENDPATH**/ ?>