<div class="slider">
    <div id="slider-larg" class="owl-carousel image-gallery">
        <!-- ITEM -->
        <?php $__currentLoopData = $rooms['fotos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item lightbox-image-icon">
            <a href="<?php echo e($foto['href']); ?>" 
            class="hover_effect h_lightbox h_blue">
                <img class="img-responsive" 
                src="<?php echo e($foto['href']); ?>" 
                alt="<?php echo e($foto['alt']); ?>">
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </div>
    <div id="thumbs" class="owl-carousel">
        <!-- ITEM -->
        <?php $__currentLoopData = $rooms['fotos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <div class="item"><img 
            class="img-responsive" 
            src="<?php echo e($foto['href']); ?>" 
            alt="<?php echo e($foto['alt']); ?>">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
            
        
      
</div><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/rooms/images_rooms.blade.php ENDPATH**/ ?>