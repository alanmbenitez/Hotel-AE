


<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
Somos un hotel de Categoria ubicado en plena Ciudad de Buenos aires
<?php $__env->stopSection(); ?>

<?php $__env->startSection('logo_menu'); ?>
<?php echo e(asset('images\logo2.png')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('navBar'); ?>
<?php $__env->startComponent('components.general.nav_general'); ?>
<?php if (isset($__componentOriginal98993a882325e38796e641a13b1bd31878f9e0da)): ?>
<?php $component = $__componentOriginal98993a882325e38796e641a13b1bd31878f9e0da; ?>
<?php unset($__componentOriginal98993a882325e38796e641a13b1bd31878f9e0da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

     
     
 
     
     <!-- =========== PAGE TITLE ========== -->
        <?php echo $__env->make('components.rooms.hero_rooms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- =========== MAIN ========== -->
        <main id="room_page">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <?php echo $__env->make('components.rooms.images_rooms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('components.rooms.info_rooms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('components.rooms.services_room', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('components.rooms.other_rooms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                    </div>
                    <div class="col-md-4">
                        <?php $__env->startComponent('components.general.Form_reserva'); ?>
                        <?php if (isset($__componentOriginald9c27f375020190b8bd5547f1ae37235430ab112)): ?>
<?php $component = $__componentOriginald9c27f375020190b8bd5547f1ae37235430ab112; ?>
<?php unset($__componentOriginald9c27f375020190b8bd5547f1ae37235430ab112); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                    </div>
                </div>
            </div>
        </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/pages/rooms/singleRoom.blade.php ENDPATH**/ ?>