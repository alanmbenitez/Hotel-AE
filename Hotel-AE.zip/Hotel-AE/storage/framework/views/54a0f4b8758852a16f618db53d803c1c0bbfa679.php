<div class="page_title gradient_overlay hero_blog_img" >
    <div class="container">
        <div class="inner">
        <h1><?php echo e(__('blog.title_hero')); ?></h1>
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/blog/blog_title.blade.php ENDPATH**/ ?>