<div>
    <div class="main_title mt50">
    <h2><?php echo e($rooms['title_content']); ?></h2>
    </div>
    <?php $__currentLoopData = $rooms['contenido']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parrafo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<p><?php echo e($parrafo); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    
    </div><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/rooms/info_rooms.blade.php ENDPATH**/ ?>