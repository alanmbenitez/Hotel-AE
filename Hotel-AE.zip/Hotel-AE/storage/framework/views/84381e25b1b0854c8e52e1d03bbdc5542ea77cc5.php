

<?php $__env->startSection('title'); ?>
Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('description'); ?>
Somos un hotel de Categoria ubicado en plena Ciudad de Buenos aires
<?php $__env->stopSection(); ?>

<?php $__env->startSection('logo_menu'); ?>
<?php echo e(asset('images\logo1.png')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('navBar'); ?>
<?php $__env->startComponent('components.home.nav_home'); ?>
    
<?php if (isset($__componentOriginal9a9d83b59df511e8d30bf327640c297ef8453f4c)): ?>
<?php $component = $__componentOriginal9a9d83b59df511e8d30bf327640c297ef8453f4c; ?>
<?php unset($__componentOriginal9a9d83b59df511e8d30bf327640c297ef8453f4c); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('revolution'); ?>
    <?php $__env->startComponent('components.home.revolution_slider'); ?>
        
    <?php if (isset($__componentOriginalef17bad8c45b4068b225b86ab70928d942f43a12)): ?>
<?php $component = $__componentOriginalef17bad8c45b4068b225b86ab70928d942f43a12; ?>
<?php unset($__componentOriginalef17bad8c45b4068b225b86ab70928d942f43a12); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('main'); ?>




<?php $__env->startComponent('components.home.favorite_rooms'); ?>
<?php if (isset($__componentOriginal2b576eeff4be3e55d737f2f5a07c490b8825d1cd)): ?>
<?php $component = $__componentOriginal2b576eeff4be3e55d737f2f5a07c490b8825d1cd; ?>
<?php unset($__componentOriginal2b576eeff4be3e55d737f2f5a07c490b8825d1cd); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<!-- ========== FEATURES ========== -->
<?php $__env->startComponent('components.home.banner_services'); ?>
<?php if (isset($__componentOriginal746e034c0e76dee9ed07f9ef128058c9cd13b6b4)): ?>
<?php $component = $__componentOriginal746e034c0e76dee9ed07f9ef128058c9cd13b6b4; ?>
<?php unset($__componentOriginal746e034c0e76dee9ed07f9ef128058c9cd13b6b4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<!-- ========== BLOG ========== -->

<!-- ========== VIDEO ========== -->

<!-- ========== TESTIMONIALS ========== -->

<!-- ========== PLACES ========== -->

<!-- ========== CONTACT ========== -->
<?php $__env->startComponent('components.home.contact'); ?>
<?php if (isset($__componentOriginal428be81e95f2da7a6d655d63ebce19f38de3ab9b)): ?>
<?php $component = $__componentOriginal428be81e95f2da7a6d655d63ebce19f38de3ab9b; ?>
<?php unset($__componentOriginal428be81e95f2da7a6d655d63ebce19f38de3ab9b); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/pages/home/home.blade.php ENDPATH**/ ?>