<div class="page_title gradient_overlay" style="background: url(images/single.png);">
    <div class="container">
        <div class="inner">
            <h1>Guia de Buenos aires</h1>
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Hotel-airesExpress\Hotel-AE\resources\views/components/home/blog_title.blade.php ENDPATH**/ ?>